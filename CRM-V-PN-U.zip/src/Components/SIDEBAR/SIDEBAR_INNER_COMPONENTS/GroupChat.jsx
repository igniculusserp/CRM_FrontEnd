export default function GroupChat(){
    return(
        <>
            <h1>Group Chat</h1>
        </>
    )
}