const main_base_url = "https://stratagem.copulaa.com/api"
const tenant_base_url = "copulaa.com/api"
const protocal_url = "https://"
const urlchange_base = "igniculusscrm.com"
const localBase = "localhost:5173"
export { main_base_url, tenant_base_url, protocal_url, urlchange_base, localBase};
          