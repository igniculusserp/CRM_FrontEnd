export default function Analytics(){
    return(
        <>
            <h1>Analytics</h1>
        </>
    )
}