export default function CreateLogin() {
  return (
    <div>CreateLogin</div>
  )
}