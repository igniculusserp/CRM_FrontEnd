//components
import VerifyTenant from './Components/REGISTRATION/VerifyTenant.jsx';

function App() {
  return (
    <>
      <VerifyTenant />
    </>
  );
}

export default App;
